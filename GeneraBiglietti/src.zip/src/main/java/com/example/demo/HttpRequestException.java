package com.example.demo;

public class HttpRequestException extends Exception {

}
