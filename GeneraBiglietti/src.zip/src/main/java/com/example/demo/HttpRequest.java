package com.example.demo;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.json.JSONArray;

public class HttpRequest {

	private final RestTemplate restTemplate;
	private ArrayList<Step> tratteCampania = new ArrayList<Step>();
	private ArrayList<Step> tratteNonCoperte = new ArrayList<Step>();
	
	public HttpRequest() {
		
		this.restTemplate = new RestTemplate();
		
	}
	
	public String getPercorsi(String origine, String destinazione) {
		
		String directionsUrl = "https://maps.googleapis.com/maps/api/directions/json?"
				+ "origin=" + origine 
				+ "&destination=" + destinazione 
				+ "&key=AIzaSyAMIldziQUKMvnnWpa0YlQveklMuQC20Ag"
				+ "&alternatives=true&language=it&mode=transit&transit_mode=&transit_routing_preference=fewer_transfers";
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("origine", origine);
		headers.set("destinazione", destinazione);
		
		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<String> response = this.restTemplate.exchange(directionsUrl, HttpMethod.GET, request, String.class);
		
		JSONObject percorsiJSON = new JSONObject(response.getBody());
		JSONObject route, leg, step, startLocationJSON, endLocationJSON;
		JSONArray routes = percorsiJSON.getJSONArray("routes");
		JSONArray legs, steps;
		String startLatitude, startLongitude, endLatitude, endLongitude;
		Location startLocation, endLocation;
		
		for (int i=0; i<routes.length(); i++) {
			route = routes.getJSONObject(i);
			legs = route.getJSONArray("legs");
			
			for (int j=0; j<legs.length(); j++) {
				leg = legs.getJSONObject(j);
				steps = leg.getJSONArray("steps");
				
				for (int k=0; k<steps.length(); k++) {
					step = steps.getJSONObject(k);
					
					if(!step.get("travel_mode").equals("WALKING")) {
						startLocationJSON = step.getJSONObject("start_location");
						
						startLatitude = (startLocationJSON.getBigDecimal("lat")).toString();
						startLongitude = (startLocationJSON.getBigDecimal("lng")).toString();
						
						if(checkLocation(startLatitude, startLongitude)) {
							
							
							endLocationJSON = step.getJSONObject("end_location");
							
							endLatitude = (endLocationJSON.getBigDecimal("lat")).toString();
							endLongitude = (endLocationJSON.getBigDecimal("lng")).toString();
							
							startLocation = new Location(startLatitude, startLongitude);
							endLocation = new Location(endLatitude, endLongitude);
							
							if(checkLocation(endLatitude, endLongitude)) {
								System.out.println("\n");
								
								tratteCampania.add(new Step(startLocation, endLocation));
							}
							else {
								System.out.println("\n");
								
								tratteNonCoperte.add(new Step(startLocation, endLocation));
							}
						}
					}
				}
			}
		}
		
		//if (response.getStatusCode() == HttpStatus.OK) {
			return response.getBody();
		//}
		//else
		
	}
	
	
	public boolean checkLocation(String latitude, String longitude) {
		
		String reverseGeocodingUrl = "https://api.bigdatacloud.net/data/reverse-geocode-client?"
				+ "latitude=" + latitude
				+ "&longitude=" + longitude 
				+ "&localityLanguage=it";
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("latitude", latitude);
		headers.set("longitude", longitude);
		
		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<String> response = this.restTemplate.exchange(reverseGeocodingUrl, HttpMethod.GET, request, String.class);
		
		JSONObject locationJSON = new JSONObject(response.getBody());
		
		if(locationJSON.getString("principalSubdivision").equals("Campania")) {
			System.out.println("La location " + locationJSON.getString("locality") + " (latitudine=" + latitude + ", longitudine=" + longitude + ") si trova in Campania");
			return true;
		}
		else {
			System.out.println("La location " + locationJSON.getString("locality") + " (latitudine=" + latitude + ", longitudine=" + longitude + ") NON si trova in Campania");
			return false;
		}
	}
}
