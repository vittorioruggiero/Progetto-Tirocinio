package com.example.demo;

public class Step {

	private Location startLocation;
	private Location endLocation;
	
	public Step(Location startLocation, Location endLocation) {
		super();
		this.startLocation = startLocation;
		this.endLocation = endLocation;
	}

	public Location getStartLocation() {
		return startLocation;
	}

	public void setStartLocation(Location startLocation) {
		this.startLocation = startLocation;
	}

	public Location getEndLocation() {
		return endLocation;
	}

	public void setEndLocation(Location endLocation) {
		this.endLocation = endLocation;
	}
	
}
